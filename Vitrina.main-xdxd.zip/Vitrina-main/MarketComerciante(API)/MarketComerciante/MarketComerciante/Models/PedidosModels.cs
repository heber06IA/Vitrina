﻿namespace MarketComerciante.Models
{
    public class Pedidos
    {
        public int PedidoID { get; set; }
        public int CompradorID { get; set; }
        public Comprador comprador { get; set; }
        public decimal MontoTotal { get; set; }
        public string Estado { get; set; } = string.Empty;
        public string MetodoPago { get; set; } = string.Empty;
        public DateTime? FechaPedido { get; set; }// ?=Permite valores nulos
    }
    public class spDeletePedidosResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeletePedidosResults
    {
        public int return_value { get; set; }
        public spDeletePedidosResponse datos { get; set; } = new();
    }
    public class spGetAllPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Pedidos> ListasdePedidos { get; set; } = new List<Pedidos>();
    }
    public class spGetAllIdPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Pedidos datos { get; set; } = new Pedidos();
    }
    public class spInsertPedidosResponse
    {
        public int CompradorID { get; set; }
        public decimal MontoTotal { get; set; }
        public string MetodoPago { get; set; }
    }
    public class spInsertPedidosResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUpdatePedidosResponse
    {
        public int IdExistente { get; set; }
        public string Estado { get; set; } = string.Empty;
        public decimal MontoTotal { get; set; }
        public string MetodoPago { get; set; } = string.Empty;
    } 
    public class spUpdatePedidosResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdatePedidosResponse datos { get; set; }
    }
}
