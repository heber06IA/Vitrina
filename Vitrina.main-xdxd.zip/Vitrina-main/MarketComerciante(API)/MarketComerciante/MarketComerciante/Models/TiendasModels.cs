﻿namespace MarketComerciante.Models
{
    public class Tiendas
    {
        public int TiendaID { get; set; }
        public  int UsuarioID { get; set; }
        public Usuarios Usuario { get; set; }
        public string NombreTienda {  get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string DireccionOrigen {  get; set; } = string.Empty;
        public decimal LatitudOrigen {  get; set; }
        public decimal LongitudOrigen { get; set; }
        public DateTime? FechaCreacion { get; set; }
    }
    public class spDeleteTiendasResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteTiendasResults
    {
        public int return_value { get; set; }
        public spDeleteTiendasResponse datos { get; set; } = new();
    }
    public class spGetAllTiendasResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Tiendas> ListasdeTiendas { get; set; } = new List<Tiendas>();
    }
    public class spGetAllIdTiendasResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Tiendas datos { get; set; } = new Tiendas();
    }
    public class spInsertTiendasResponse
    {
        public int UsuarioID { get; set; }
        public string NombreTienda {  get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string DireccionOrigen { get; set; } = string.Empty;
        public decimal LatitudOrigen { get; set; }
        public decimal LongitudOrigen { get; set; }
    }
    public class spInsertTiendasResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spInsertTiendasResponse datos { get; set; }
    }
    public class spUdateTiendasResponse
    {
        public int IdExistente { get; set; }
        public string NombreTienda { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public string DireccionOrigen { get; set; } = string.Empty;
        public decimal LatitudOrigen { get; set; }
        public decimal LongitudOrigen { get; set; }
    }
    public class spUpdateTiendasResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUdateTiendasResponse datos { get; set; }
    }
}
