﻿namespace MarketComerciante.Models
{
    public class Comprador
    {
        public int CompradorID { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Correo {  get; set; } = string.Empty;
        public string PasswordHash {  get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public DateTime? FechaRegistro { get; set; }
    }
    public class spDeleteCompradorResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; }= string.Empty;
    }
    public class spDeleteCompradorResults
    {
        public int return_value { get; set; }
        public spDeleteCompradorResponse datos { get; set; } = new();
    }
    public class spGetAllCompradorResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; }= string.Empty;
        public IEnumerable<Comprador> ListadeCompradores { get; set; }= new List<Comprador> ();
    }
    public class spGetAllIdCompradorResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Comprador datos { get; set; } = new Comprador();
    }
    public class spInsertCompradorResponse
    {
        public string Nombre { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
    }
    public class spInsertCompradorResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUdateCompradorResponse
    {
        public string Nombre { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
    }
    
    public class spUpdateCompradorResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUdateCompradorResponse datos { get; set; } = new();
    }
}
