﻿namespace MarketComerciante.Models
{ 
    public class Carrito
    {
        public int CarritoID { get; set; }
        public int UsuarioID { get; set; }
        public Usuarios Usuario { get; set; }

        public int ProductoID { get; set; }
        public Productos Producto { get; set; }
        public int Cantidad { get; set; }
        public DateTime? FechaAgregado { get; set; }
    }
    public class spDeleteCarritoResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado {  get; set; }
        public string mensaje_respuesta { get; set; }= string.Empty;
    }
    public class spDeleteCarritoResults
    {
        public int return_value { get; set; }
        public spDeleteCarritoResponse datos { get; set; } = new();
    }
    public class spGetAllCarritoResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; }= string.Empty;
        public IEnumerable<Carrito> ListasdeCarritos { get; set; } = new List<Carrito>();  
    }
    public class spGetAllIdCarritoResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; }= string.Empty;
        public Carrito datos { get; set; } = new Carrito();
    }
    public class spInsertCarritoResponse
    {
        public int UsuarioID { get; set; }
        public int ProductoID { get; set; }
        public int  Cantidad { get; set; }
        public DateTime? FechaAgregado { get; set; }
    }
    public class spInsertCarritoResults
    {
        public int return_value { get; set; }
        public int id_insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spInsertCarritoResponse? datos { get; set; }
    }
    public class   spUdateCarritoResponse
    {
        public int IdExistente { get; set; }
        public int Cantidad { get; set; }
    }
    public class spUpdateCarritoResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUdateCarritoResponse datos { get; set; }
    }
}
    