﻿namespace MarketComerciante.Models
{
    public class GeolocalizacionPedidos
    { 
        public int UbicacionID { get; set; }
        public int PedidoID { get; set; }
        public Pedidos Pedido { get; set; }
        public decimal LatitudActual { get; set; }
        public decimal LongitudActual { get; set; }
        public DateTime? UltimaActualizacion {  get; set; }
    }
    public class spDeleteGeoPedidosResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteGeoPedidosResults
    {
        public int return_value { get; set; }
        public spDeleteGeoPedidosResponse datos { get; set; } = new();
    }
    public class spGetAllGeoPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<GeolocalizacionPedidos> ListadeGeoPedidos { get; set; } = new List<GeolocalizacionPedidos>();
    }
    public class spGetAllIdGeoPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public GeolocalizacionPedidos datos { get; set; } = new GeolocalizacionPedidos();
    }
    public class spInsertGeoPedidosResponse
    {
        public int PedidoID { get; set; }
        public decimal LatitudActual { get; set; }
        public decimal LongitudActual { get; set; }
    }
    public class spInsertGeoPedidosResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public GeolocalizacionPedidos? datos { get; set; } 
    }
    public class spUpdateGeoPedidosResponse
    {
        public int IdExistente { get; set; }
        public int PedidoID { get; set; }
        public decimal LatitudActual { get; set; }
        public decimal LongitudActual { get; set; }
    }
    public class spUpdateGeoPedidosResults
    {
        public int return_value { get; set; }
        public int IdActualizado {  get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateGeoPedidosResponse datos { get; set; }
    }
}
