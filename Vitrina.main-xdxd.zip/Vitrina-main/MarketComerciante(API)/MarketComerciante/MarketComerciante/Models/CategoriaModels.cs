﻿using Microsoft.Extensions.Primitives;

namespace MarketComerciante.Models
{
    public class Categorias
    {
        public int CategoriaID { get; set; }
        public string Nombre { get; set; } = string.Empty;

    }
    public class spDeleteCategoriasResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteCategoriasResults
    {
        public int return_value { get; set; }
        public spDeleteCategoriasResponse datos { get; set; } = new();
    }
    public class spGetAllCategoriasResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Categorias> ListadeCategorias { get; set; } = new List<Categorias>();
    }
    public class spGetAllIdCategoriasResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Categorias datos { get; set; } = new Categorias();
    }
    public class spInsertCategoriasResponse
    {
        public string Nombre { get; set; } = string.Empty;
    }
    public class spInsertCategoriasResults
    {
        public int return_value { get; set; }
        public int id_insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUpdateCategoriasResponse
    {
        public int IdExistente { get; set; }
        public string Nombre { get; set; } = string.Empty;
    }
    public class spUpdateCategoriasResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateCategoriasResponse datos { get; set; }
    }

}
