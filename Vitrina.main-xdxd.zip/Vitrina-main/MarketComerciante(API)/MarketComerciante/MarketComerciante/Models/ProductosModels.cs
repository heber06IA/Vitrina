﻿namespace MarketComerciante.Models
{
    public class Productos
    {
        public int ProductoID { get; set; }//[get; set;]= accede y modifica los atributos P. de una clase.
        public int TiendaID { get; set; }
        public Tiendas tienda { get; set; }
        public int CategoriaID { get; set; }
        public Categorias categoria { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public decimal Precio {  get; set; }
        public int Stock { get; set; }
        public string ImagenUrl { get; set; } = string.Empty;
        public bool? Activo {  get; set; }
        public DateTime? FechaCreacion { get; set; }

    }
    public class spDeleteProductosResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteProductosResults
    {
        public int return_value { get; set; }
        public spDeleteProductosResponse datos { get; set; } = new();
    }
    public class spGetAllProductosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Productos> ListasdeProductos { get; set; } = new List<Productos>();
    }
    public class spGetAllIdProductosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Productos datos { get; set; } = new Productos();
    }
    public class spInsertProductosResponse
    {
        public int TiendaID { get; set; }
        public int CategoriaID { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public decimal Precio { get; set; }
        public int Stock { get; set; }
        public string ImagenUrl { get; set; } = string.Empty;

    }
    public class spInsertProductosResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spInsertProductosResponse datos { get; set; }
    }
    public class spUpdateProductosResponse
    {
        public int IdExistente { get; set; }
        public int TiendaID { get; set; }
        public int CategoriaID { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public decimal Precio { get; set; }
        public int Stock { get; set; }
        public string ImagenUrl { get; set; } = string.Empty;
        public bool? Activo { get; set; }
    }
    public class spUpdateProductosResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateProductosResponse datos { get; set; }
    }
}
    

