﻿namespace MarketComerciante.Models
{
    public class DetallePedidos
    {
        public int DetalleID { get; set; }
        public int PedidoID { get; set; }
        public Pedidos Pedido { get; set; }
        public int ProductoID { get; set; }
        public Productos Producto { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario { get; set; }
    }
    public class spDeleteDetPedidosResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteDetPedidoResults
    {
        public int return_value { get; set; }
        public spDeleteDetPedidosResponse datos { get; set; } = new();
    }
    public class spGetAllDetPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<DetallePedidos> ListadeDetallesPedidos { get; set; } = new List<DetallePedidos>();
    }
    public class spGetAllIdDetPedidosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public DetallePedidos datos { get; set; } = new DetallePedidos();
    }
    public class spInsertDetPedidosResponse
    {
        public int PedidoID { get; set; }
        public int ProductoID { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario { get; set; }
    }
    public class spInsertDetPedidosResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUpdateDetPedidosResponse
    {
        public int IdExistente { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario { get; set; }
    }
    public class spUpdateDetPedidosResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateDetPedidosResponse datos { get; set; }
    }
}