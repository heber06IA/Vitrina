﻿namespace MarketComerciante.Models
{
    public class Roles
    {
        public int RolID { get; set; }
        public string Nombre { get; set; } = string.Empty;
    }
    public class spDeleteRolesResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteRolesResults
    {
        public int return_value { get; set; }
        public spDeleteRolesResponse datos { get; set; } = new();
    }
    public class spGetAllRolesResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Roles> ListasdeRoles { get; set; } = new List<Roles>();
    }
    public class spGetAllIdRolesResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Roles datos { get; set; } = new Roles();
    }
    public class spInsertRolesResponse
    {
        public string NombreRol { get; set; } = string.Empty;

    }
    public class spInsertRolesResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUpdateRolesResponse
    {
        public int IdExistente { get; set; }
        public string NombreRol { get; set; } = string.Empty;
    }
    public class spUpdateRolesResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateRolesResponse datos { get; set; }
    }
}
