﻿namespace MarketComerciante.Models
{
    public class Usuarios
    {
        public int UsuarioID { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public int RolID { get; set; } 
        public Roles Rol {  get; set; }
        public DateTime? FechaRegistro { get; set; }
    }
    public class spDeleteUsuariosResponse
    {
        public int IDaEliminar { get; set; }
        public int IDeliminado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spDeleteUsuariosResults
    {
        public int return_value { get; set; }
        public spDeleteUsuariosResponse datos { get; set; }
    }
    public class spGetAllUsuariosResult
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public IEnumerable<Usuarios> ListasdeUsuarios { get; set; } = new List<Usuarios>();
    }
    public class spGetAllIdUsuariosResults
    {
        public int return_value { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public Usuarios datos { get; set; }= new Usuarios();
    }
    public class spInsertUsuariosResponse
    {
        public string Nombre { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public int RolID { get; set; }
        public Roles rol { get; set; }
    }
    public class spInsertUsuariosResults
    {
        public int return_value { get; set; }
        public int id_Insertado { get; set; }

        public string mensaje_respuesta { get; set; } = string.Empty;
    }
    public class spUpdateUsuariosResponse
    {
        public int IdExistente { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public int RolID { get; set; }
        public Roles rol { get; set; }
    }
    public class spUpdateUsuariosResults
    {
        public int return_value { get; set; }
        public int IdActualizado { get; set; }
        public string mensaje_respuesta { get; set; } = string.Empty;
        public spUpdateUsuariosResponse datos { get; set; }
    }
}
