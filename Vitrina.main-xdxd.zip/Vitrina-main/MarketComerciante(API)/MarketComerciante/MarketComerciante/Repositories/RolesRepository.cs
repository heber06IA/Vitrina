﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // INTERFAZ DEL REPOSITORIO DE ROLES
    public interface IRolesRepository
    {
        Task<spGetAllRolesResults> GetAllAsync();
        Task<spGetAllIdRolesResults> GetByIdAsync(int rolId);
        Task<spInsertRolesResults> InsertAsync(Roles model);
        Task<spUpdateRolesResults> UpdateAsync(int idExistente, string nombreRol);
        Task<spDeleteRolesResults> DeleteAsync(int rolId);
    }
    // IMPLEMENTACIÓN CON DAPPER
    public class RolesRepository : IRolesRepository
    {
        private readonly IDbConnection _dbConnection;

        public RolesRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllRolesResults> GetAllAsync()
        {
            var resultado = new spGetAllRolesResults();
            var query = "spGetAllRoles";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var roles = await _dbConnection.QueryAsync<Roles>(
                    query,
                    parameters, // <- Pasamos los parámetros aquí
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListasdeRoles = roles.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito"; // <- Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListasdeRoles = new List<Roles>();
            }

            return resultado;
        }

        public async Task<spGetAllIdRolesResults> GetByIdAsync(int rolId)
        {
            var resultado = new spGetAllIdRolesResults();
            var query = "spGetAllIdRoles";
            var parameters = new DynamicParameters();

            // Validación de ID positivo
            if (rolId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El RolID proporcionado no es válido.";
                resultado.datos = new Roles();
                return resultado;
            }

            parameters.Add("@RolID", rolId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var rol = await _dbConnection.QueryFirstOrDefaultAsync<Roles>(
                    query,
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = rol ?? new Roles();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Roles();
            }

            return resultado;
        }

        public async Task<spInsertRolesResults> InsertAsync(Roles model)
        {
            var resultado = new spInsertRolesResults();
            var query = "spInsertRoles";
            var parameters = new DynamicParameters();

            // Validación de negocio: El nombre del rol no puede estar vacío
            if (model == null || string.IsNullOrWhiteSpace(model.Nombre))
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: El nombre del rol es obligatorio.";
                return resultado;
            }

            parameters.Add("@NombreRol", model.Nombre.Trim());

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdateRolesResults> UpdateAsync(int idExistente, string nombreRol)
        {
            var resultado = new spUpdateRolesResults();
            var query = "spUpdateRoles";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || string.IsNullOrWhiteSpace(nombreRol))
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente debe ser mayor a cero y el nombre del rol no puede estar vacío.";
                resultado.datos = null;
                return resultado;
            }

            // Parámetros de entrada ajustados a los nombres exactos del SP
            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@NombreRol", nombreRol.Trim());

            // Parámetros OUTPUT ajustados al nombre exacto del SP (@IdActualizado)
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Rol actualizado exitosamente.";

                resultado.datos = new spUpdateRolesResponse
                {
                    IdExistente = idExistente,
                    NombreRol = nombreRol.Trim()
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteRolesResults> DeleteAsync(int rolId)
        {
            var resultado = new spDeleteRolesResults();
            var query = "spDeleteRoles";
            var parameters = new DynamicParameters();

            if (rolId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteRolesResponse
                {
                    IDaEliminar = rolId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID del rol a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetro de entrada exacto que espera tu SP
            parameters.Add("@IDaEliminar", rolId);

            // Parámetros OUTPUT con los nombres exactos definidos en el SP
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteRolesResponse
                {
                    IDaEliminar = rolId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteRolesResponse
                {
                    IDaEliminar = rolId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}