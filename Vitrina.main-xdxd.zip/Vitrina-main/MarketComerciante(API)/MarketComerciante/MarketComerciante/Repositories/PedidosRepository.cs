﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // ==========================================
    // INTERFAZ DEL REPOSITORIO DE PEDIDOS
    // ==========================================
    public interface IPedidosRepository
    {
        Task<spGetAllPedidosResults> GetAllAsync();
        Task<spGetAllIdPedidosResults> GetByIdAsync(int pedidoId);
        Task<spInsertPedidosResults> InsertAsync(spInsertPedidosResponse model);
        Task<spUpdatePedidosResults> UpdateAsync(int idExistente, spUpdatePedidosResponse model);
        Task<spDeletePedidosResults> DeleteAsync(int pedidoId);
    }

    // ==========================================
    // IMPLEMENTACIÓN CON DAPPER
    // ==========================================
    public class PedidosRepository : IPedidosRepository
    {
        private readonly IDbConnection _dbConnection;

        public PedidosRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllPedidosResults> GetAllAsync()
{
    var resultado = new spGetAllPedidosResults();
    var query = "spGetAllPedidos";
    var parameters = new DynamicParameters();

    parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

    try
    {
        if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
        {
            _dbConnection.Open();
        }

                // Usamos Multi-Mapping con Dapper para mapear DetallePedidos -> Pedidos -> Productos
                var pedidos = await _dbConnection.QueryAsync<Pedidos>(
            query,
            parameters,
            commandType: CommandType.StoredProcedure
        );

        resultado.ListasdePedidos = pedidos.ToList();
        resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Éxito";
        resultado.return_value = 0;
    }
    catch (Exception ex)
    {
        resultado.return_value = -1;
        resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
        resultado.ListasdePedidos = new List<Pedidos>();
    }

    return resultado;
}

        public async Task<spGetAllIdPedidosResults> GetByIdAsync(int pedidoId)
        {
            var resultado = new spGetAllIdPedidosResults();
            var query = "spGetAllIdPedidos";
            var parameters = new DynamicParameters();

            if (pedidoId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El PedidoID proporcionado no es válido.";
                resultado.datos = new Pedidos();
                return resultado;
            }

            parameters.Add("@PedidoID", pedidoId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var pedidoList = await _dbConnection.QueryAsync<Pedidos, Comprador, Pedidos>(
                    query,
                    (pedido, comprador) =>
                    {
                        pedido.comprador = comprador; // Asignamos el comprador hidratado al pedido
                        return pedido;
                    },
                    parameters,
                    splitOn: "IdComprador",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = pedidoList.FirstOrDefault() ?? new Pedidos();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Pedidos();
            }

            return resultado;
        }

        public async Task<spInsertPedidosResults> InsertAsync(spInsertPedidosResponse model)
        {
            var resultado = new spInsertPedidosResults();
            var query = "spInsertPedidos";
            var parameters = new DynamicParameters();

            // Validación de negocio: CompradorID válido, MontoTotal positivo y MetodoPago obligatorio
            if (model == null || model.CompradorID <= 0 || model.MontoTotal <= 0 || string.IsNullOrWhiteSpace(model.MetodoPago))
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: CompradorID y MontoTotal deben ser mayores a cero, y el MetodoPago es obligatorio.";
                return resultado;
            }

            parameters.Add("@CompradorID", model.CompradorID);
            parameters.Add("@MontoTotal", model.MontoTotal);
            parameters.Add("@MetodoPago", model.MetodoPago.Trim());

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdatePedidosResults> UpdateAsync(int idExistente, spUpdatePedidosResponse model)
        {
            var resultado = new spUpdatePedidosResults();
            var query = "spUpdatePedidos";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || model == null || model.MontoTotal <= 0 || string.IsNullOrWhiteSpace(model.Estado) || string.IsNullOrWhiteSpace(model.MetodoPago))
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente debe ser mayor a cero, el MontoTotal positivo, y los campos Estado y MetodoPago son obligatorios.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@Estado", model.Estado.Trim());
            parameters.Add("@MontoTotal", model.MontoTotal);
            parameters.Add("@MetodoPago", model.MetodoPago.Trim());

            // Parámetros OUTPUT del procedimiento almacenado (ajustados al nombre exacto: @IdActualizado)
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Pedido actualizado correctamente.";

                resultado.datos = new spUpdatePedidosResponse
                {
                    IdExistente = idExistente,
                    Estado = model.Estado.Trim(),
                    MontoTotal = model.MontoTotal,
                    MetodoPago = model.MetodoPago.Trim()
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeletePedidosResults> DeleteAsync(int pedidoId)
        {
            var resultado = new spDeletePedidosResults();
            var query = "spDeletePedidos";
            var parameters = new DynamicParameters();

            if (pedidoId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeletePedidosResponse
                {
                    IDaEliminar = pedidoId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID de pedido a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetro de entrada exacto que espera tu SP
            parameters.Add("@IDaEliminar", pedidoId);

            // Parámetros OUTPUT que devuelve tu SP
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeletePedidosResponse
                {
                    IDaEliminar = pedidoId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeletePedidosResponse
                {
                    IDaEliminar = pedidoId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}