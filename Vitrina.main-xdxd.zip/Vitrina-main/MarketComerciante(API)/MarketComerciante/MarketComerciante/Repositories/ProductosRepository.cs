﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // ==========================================
    // INTERFAZ DEL REPOSITORIO DE PRODUCTOS
    // ==========================================
    public interface IProductosRepository
    {
        Task<spGetAllProductosResults> GetAllAsync();
        Task<spGetAllIdProductosResults> GetByIdAsync(int productoId);
        Task<spInsertProductosResults> InsertAsync(spInsertProductosResponse model);
        Task<spUpdateProductosResults> UpdateAsync(int idExistente, spUpdateProductosResponse model);
        Task<spDeleteProductosResults> DeleteAsync(int productoId);
    }

    // ==========================================
    // IMPLEMENTACIÓN CON DAPPER
    // ==========================================
    public class ProductosRepository : IProductosRepository
    {
        private readonly IDbConnection _dbConnection;

        public ProductosRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllProductosResults> GetAllAsync()
        {
            var resultado = new spGetAllProductosResults();
            var query = "spGetAllProductos";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var productos = await _dbConnection.QueryAsync<Productos, Tiendas, Categorias, Productos>(
                    query,
                    (producto, tienda, categoria) =>
                    {
                        producto.tienda = tienda;
                        producto.categoria = categoria;
                        return producto;
                    },
                    parameters,
                    splitOn: "TiendaID, CategoriaID", // Columnas clave donde Dapper separa los objetos
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListasdeProductos = productos.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListasdeProductos = new List<Productos>();
            }

            return resultado;
        }



        public async Task<spGetAllIdProductosResults> GetByIdAsync(int productoId)
        {
            var resultado = new spGetAllIdProductosResults();
            var query = "spGetAllIdProductos";
            var parameters = new DynamicParameters();

            // Validación de ID positivo
            if (productoId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El ProductoID proporcionado no es válido.";
                resultado.datos = new Productos();
                return resultado;
            }

            parameters.Add("@ProductoID", productoId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var productoList = await _dbConnection.QueryAsync<Productos, Tiendas, Categorias, Productos>(
                    query,
                    (p, t, c) =>
                    {
                        p.tienda = t;
                        p.categoria = c;
                        return p;
                    },
                    parameters,
                    splitOn: "TiendaID, CategoriaID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = productoList.FirstOrDefault() ?? new Productos();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Productos();
            }

            return resultado;
        }

        public async Task<spInsertProductosResults> InsertAsync(spInsertProductosResponse model)
        {
            var resultado = new spInsertProductosResults();
            var query = "spInsertProductos";
            var parameters = new DynamicParameters();

            // Validación de negocio: TiendaID, CategoriaID válidos, Nombre obligatorio, Precio positivo y Stock no negativo
            if (model == null || model.TiendaID <= 0 || model.CategoriaID <= 0 || string.IsNullOrWhiteSpace(model.Nombre) || model.Precio < 0 || model.Stock < 0)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: TiendaID, CategoriaID, Nombre son obligatorios, y Precio/Stock deben tener valores válidos.";
                return resultado;
            }

            parameters.Add("@TiendaID", model.TiendaID);
            parameters.Add("@CategoriaID", model.CategoriaID);
            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Descripcion", model.Descripcion?.Trim() ?? string.Empty);
            parameters.Add("@Precio", model.Precio);
            parameters.Add("@Stock", model.Stock);
            parameters.Add("@ImagenUrl", model.ImagenUrl?.Trim() ?? string.Empty);

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Producto agregado exitosamente.";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }
        public async Task<spUpdateProductosResults> UpdateAsync(int idExistente, spUpdateProductosResponse model)
        {
            var resultado = new spUpdateProductosResults();
            var query = "spUpdateProductos";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || model == null || model.CategoriaID <= 0 || string.IsNullOrWhiteSpace(model.Nombre) || model.Precio < 0 || model.Stock < 0)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente y CategoriaID deben ser válidos, el Nombre obligatorio, y Precio/Stock no negativos.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@CategoriaID", model.CategoriaID);
            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Descripcion", model.Descripcion?.Trim() ?? string.Empty);
            parameters.Add("@Precio", model.Precio);
            parameters.Add("@Stock", model.Stock);
            parameters.Add("@ImagenUrl", model.ImagenUrl?.Trim() ?? string.Empty);
            parameters.Add("@Activo", model.Activo);

            // Parámetros OUTPUT del procedimiento almacenado (Coincidiendo exactamente con @IdActualizado)
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Producto actualizado correctamente.";

                resultado.datos = new spUpdateProductosResponse
                {
                    IdExistente = idExistente,
                    TiendaID = model.TiendaID,
                    CategoriaID = model.CategoriaID,
                    Nombre = model.Nombre.Trim(),
                    Descripcion = model.Descripcion?.Trim() ?? string.Empty,
                    Precio = model.Precio,
                    Stock = model.Stock,
                    ImagenUrl = model.ImagenUrl?.Trim() ?? string.Empty,
                    Activo = model.Activo
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteProductosResults> DeleteAsync(int productoId)
        {
            var resultado = new spDeleteProductosResults();
            var query = "spDeleteProductos";
            var parameters = new DynamicParameters();

            if (productoId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteProductosResponse
                {
                    IDaEliminar = productoId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID del producto a eliminar no es válido."
                };
                return resultado;
            }

            // Coincide exactamente con el parámetro @IDAeliminar del procedimiento almacenado
            parameters.Add("@IDAeliminar", productoId);

            // Coinciden exactamente con los parámetros OUTPUT de SQL Server (@IDeliminado y @mensaje_respuesta)
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Operación realizada con éxito.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteProductosResponse
                {
                    IDaEliminar = productoId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteProductosResponse
                {
                    IDaEliminar = productoId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}