﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // INTERFAZ DEL REPOSITORIO DE TIENDAS
    public interface ITiendasRepository
    {
        Task<spGetAllTiendasResults> GetAllAsync();
        Task<spGetAllIdTiendasResults> GetByIdAsync(int tiendaId);
        Task<spInsertTiendasResults> InsertAsync(spInsertTiendasResponse model);
        Task<spUpdateTiendasResults> UpdateAsync(int idExistente, spUdateTiendasResponse model);
        Task<spDeleteTiendasResults> DeleteAsync(int tiendaId);
    }

    // IMPLEMENTACIÓN CON DAPPER
    public class TiendasRepository : ITiendasRepository
    {
        private readonly IDbConnection _dbConnection;

        public TiendasRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllTiendasResults> GetAllAsync()
        {
            var resultado = new spGetAllTiendasResults();
            var query = "spGetAllTiendas";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var tiendas = await _dbConnection.QueryAsync<Tiendas>(
                    query,
                    parameters, // <- Pasamos los parámetros aquí
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListasdeTiendas = tiendas.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito"; // <- Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListasdeTiendas = new List<Tiendas>();
            }

            return resultado;
        }
        public async Task<spGetAllIdTiendasResults> GetByIdAsync(int tiendaId)
        {
            var resultado = new spGetAllIdTiendasResults();
            var query = "spGetAllIdTiendas";
            var parameters = new DynamicParameters();

            if (tiendaId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El TiendaID proporcionado no es válido.";
                resultado.datos = new Tiendas();
                return resultado;
            }

            parameters.Add("@TiendaID", tiendaId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var tiendaList = await _dbConnection.QueryAsync<Tiendas, Usuarios, Roles, Tiendas>(
                    query,
                    (tienda, usuario, rol) =>
                    {
                        if (usuario != null)
                        {
                            usuario.Rol = rol; // Asigna el rol al usuario si viene mapeado
                            tienda.Usuario = usuario; // Asigna el usuario completo a la tienda
                        }
                        return tienda;
                    },
                    parameters,
                    splitOn: "UsuarioID, RolID", // Puntos exactos donde inician las otras tablas en el SELECT
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = tiendaList.FirstOrDefault() ?? new Tiendas();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Tiendas();
            }

            return resultado;
        }

        public async Task<spInsertTiendasResults> InsertAsync(spInsertTiendasResponse model)
        {
            var resultado = new spInsertTiendasResults();
            var query = "spInsertTiendas";
            var parameters = new DynamicParameters();

            // Validación de negocio: UsuarioID válido, NombreTienda obligatorio, rangos correctos para Latitud (-90 a 90) y Longitud (-180 a 180)
            if (model == null || model.UsuarioID <= 0 || string.IsNullOrWhiteSpace(model.NombreTienda) || model.LatitudOrigen < -90 || model.LatitudOrigen > 90 || model.LongitudOrigen < -180 || model.LongitudOrigen > 180)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: UsuarioID y NombreTienda son obligatorios, y las coordenadas geográficas deben ser válidas.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@UsuarioID", model.UsuarioID);
            parameters.Add("@NombreTienda", model.NombreTienda.Trim());
            parameters.Add("@Descripcion", model.Descripcion?.Trim() ?? string.Empty);
            parameters.Add("@DireccionOrigen", model.DireccionOrigen?.Trim() ?? string.Empty);
            parameters.Add("@LatitudOrigen", model.LatitudOrigen);
            parameters.Add("@LongitudOrigen", model.LongitudOrigen);

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Tienda creada con éxito.";

                // Si tu clase de resultados incluye la propiedad 'datos', la hidratamos con el objeto insertado
                resultado.datos = new spInsertTiendasResponse
                {
                    UsuarioID = model.UsuarioID,
                    NombreTienda = model.NombreTienda.Trim(),
                    Descripcion = model.Descripcion?.Trim() ?? string.Empty,
                    DireccionOrigen = model.DireccionOrigen?.Trim() ?? string.Empty,
                    LatitudOrigen = model.LatitudOrigen,
                    LongitudOrigen = model.LongitudOrigen
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spUpdateTiendasResults> UpdateAsync(int idExistente, spUdateTiendasResponse model)
        {
            var resultado = new spUpdateTiendasResults();
            var query = "spUpdateTiendas";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || model == null || string.IsNullOrWhiteSpace(model.NombreTienda) || model.LatitudOrigen < -90 || model.LatitudOrigen > 90 || model.LongitudOrigen < -180 || model.LongitudOrigen > 180)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente debe ser mayor a cero, el NombreTienda es obligatorio y las coordenadas geográficas deben ser válidas.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@NombreTienda", model.NombreTienda.Trim());
            parameters.Add("@Descripcion", model.Descripcion?.Trim() ?? string.Empty);
            parameters.Add("@DireccionOrigen", model.DireccionOrigen?.Trim() ?? string.Empty);
            parameters.Add("@LatitudOrigen", model.LatitudOrigen);
            parameters.Add("@LongitudOrigen", model.LongitudOrigen);

            // Parámetros OUTPUT con el nombre exacto que espera el SP (@IdActualizado)[cite: 20]
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Tienda actualizada exitosamente.";

                resultado.datos = new spUdateTiendasResponse
                {
                    IdExistente = idExistente,
                    NombreTienda = model.NombreTienda.Trim(),
                    Descripcion = model.Descripcion?.Trim() ?? string.Empty,
                    DireccionOrigen = model.DireccionOrigen?.Trim() ?? string.Empty,
                    LatitudOrigen = model.LatitudOrigen,
                    LongitudOrigen = model.LongitudOrigen
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteTiendasResults> DeleteAsync(int tiendaId)
        {
            var resultado = new spDeleteTiendasResults();
            var query = "spDeleteTiendas";
            var parameters = new DynamicParameters();

            if (tiendaId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteTiendasResponse
                {
                    IDaEliminar = tiendaId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID de tienda a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetro de entrada exacto que espera tu procedimiento almacenado
            parameters.Add("@IDaEliminar", tiendaId);

            // Parámetros OUTPUT que devuelve tu SP
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteTiendasResponse
                {
                    IDaEliminar = tiendaId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteTiendasResponse
                {
                    IDaEliminar = tiendaId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}