﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // ==========================================
    // INTERFAZ DEL REPOSITORIO DE COMPRADOR
    // ==========================================
    public interface ICompradorRepository
    {
        Task<spGetAllCompradorResults> GetAllAsync();
        Task<spGetAllIdCompradorResults> GetByIdAsync(int compradorId);
        Task<spInsertCompradorResults> InsertAsync(spInsertCompradorResponse model);
        Task<spUpdateCompradorResults> UpdateAsync(int idExistente, spUdateCompradorResponse model);
        Task<spDeleteCompradorResults> DeleteAsync(int compradorId);
    }

    // ==========================================
    // IMPLEMENTACIÓN CON DAPPER
    // ==========================================
    public class CompradorRepository : ICompradorRepository
    {
        private readonly IDbConnection _dbConnection;

        public CompradorRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllCompradorResults> GetAllAsync()
        {
            var resultado = new spGetAllCompradorResults();
            var query = "spGetAllComprador";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var comprador = await _dbConnection.QueryAsync<Comprador>(
                    query,
                    parameters, // <- Pasamos los parámetros aquí
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListadeCompradores = comprador.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito"; // <- Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListadeCompradores = new List<Comprador>();
            }

            return resultado;
        }

        public async Task<spGetAllIdCompradorResults> GetByIdAsync(int compradorId)
        {
            var resultado = new spGetAllIdCompradorResults();
            var query = "spGetAllIdComprador";
            var parameters = new DynamicParameters();

            // Validación de ID positivo
            if (compradorId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El IDComprador proporcionado no es válido.";
                resultado.datos = new Comprador();
                return resultado;
            }

            parameters.Add("@IDComprador", compradorId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var comprador = await _dbConnection.QueryFirstOrDefaultAsync<Comprador>(
                    query,
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = comprador ?? new Comprador();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Comprador();
            }

            return resultado;
        }

        public async Task<spInsertCompradorResults> InsertAsync(spInsertCompradorResponse model)
        {
            var resultado = new spInsertCompradorResults();
            var query = "spInsertComprador";
            var parameters = new DynamicParameters();

            if (model == null || string.IsNullOrWhiteSpace(model.Correo))
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "El correo del comprador es obligatorio.";
                return resultado;
            }

            // Parámetros de entrada que exige el SP en SQL Server
            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Correo", model.Correo.Trim());
            parameters.Add("@PasswordHash", model.PasswordHash);
            parameters.Add("@Telefono", model.Telefono?.Trim());

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Comprador registrado exitosamente.";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdateCompradorResults> UpdateAsync(int idExistente, spUdateCompradorResponse model)
        {
            var resultado = new spUpdateCompradorResults();
            var query = "spUpdateComprador"; // Ajusta si tu SP tiene otro nombre
            var parameters = new DynamicParameters();

            // Validación de parámetros de actualización
            if (idExistente <= 0 || model == null || string.IsNullOrWhiteSpace(model.Nombre) || string.IsNullOrWhiteSpace(model.Correo))
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente debe ser mayor a cero y los campos Nombre y Correo son obligatorios.";
                resultado.datos = null;
                return resultado;
            }

            // Parámetros de entrada que exige el SP en SQL Server
            parameters.Add("@IdExistente", idExistente); // <-- Cambiado de @idexistente a @IdExistente
            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Correo", model.Correo.Trim());
            parameters.Add("@PasswordHash", model.PasswordHash?.Trim() ?? string.Empty);
            parameters.Add("@Telefono", model.Telefono?.Trim() ?? string.Empty);

            // Parámetros OUTPUT del procedimiento almacenado (¡Faltaba declarar @IdActualizado aquí!)
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.return_value = 0;
                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Comprador actualizado exitosamente.";
                resultado.datos = new spUdateCompradorResponse
                {
                    Nombre = model.Nombre.Trim(),
                    Correo = model.Correo.Trim(),
                    PasswordHash = model.PasswordHash?.Trim() ?? string.Empty,
                    Telefono = model.Telefono?.Trim() ?? string.Empty
                };
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteCompradorResults> DeleteAsync(int compradorId)
        {
            var resultado = new spDeleteCompradorResults();
            var query = "spDeleteComprador"; // Ajusta si tu SP tiene otro nombre
            var parameters = new DynamicParameters();

            if (compradorId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCompradorResponse
                {
                    IDaEliminar = compradorId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID a eliminar no es válido."
                };
                return resultado;
            }

            parameters.Add("@IDaEliminar", compradorId);
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta");

                resultado.return_value = 0;
                resultado.datos = new spDeleteCompradorResponse
                {
                    IDaEliminar = compradorId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCompradorResponse
                {
                    IDaEliminar = compradorId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}