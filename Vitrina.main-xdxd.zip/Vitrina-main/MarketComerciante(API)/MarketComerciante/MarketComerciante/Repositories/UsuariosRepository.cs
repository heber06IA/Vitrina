﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // ==========================================
    // INTERFAZ DEL REPOSITORIO DE USUARIOS
    // ==========================================
    public interface IUsuariosRepository
    {
        Task<spGetAllUsuariosResult> GetAllAsync();
        Task<spGetAllIdUsuariosResults> GetByIdAsync(int usuarioId);
        Task<spInsertUsuariosResults> InsertAsync(Usuarios model);
        Task<spUpdateUsuariosResults> UpdateAsync(int idExistente, Usuarios model);
        Task<spDeleteUsuariosResults> DeleteAsync(int usuarioId);
    }

    // ==========================================
    // IMPLEMENTACIÓN CON DAPPER
    // ==========================================
    public class UsuariosRepository : IUsuariosRepository
    {
        private readonly IDbConnection _dbConnection;

        public UsuariosRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllUsuariosResult> GetAllAsync()
        {
            var resultado = new spGetAllUsuariosResult();
            var query = "spGetAllUsuarios";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var usuariosList = await _dbConnection.QueryAsync<Usuarios, Roles, Usuarios>(
                    query,
                    (usuario, rol) =>
                    {
                        usuario.Rol = rol; // Asignamos el objeto rol hidratado al usuario
                        return usuario;
                    },
                    parameters,
                    splitOn: "RolID", // La columna exacta donde comienza el mapeo de la entidad Roles
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListasdeUsuarios = usuariosList.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListasdeUsuarios = new List<Usuarios>();
            }

            return resultado;
        }
        public async Task<spGetAllIdUsuariosResults> GetByIdAsync(int usuarioId)
        {
            var resultado = new spGetAllIdUsuariosResults();
            var query = "spGetAllIdUsuarios";
            var parameters = new DynamicParameters();

            if (usuarioId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El UsuarioID proporcionado no es válido.";
                resultado.datos = new Usuarios();
                return resultado;
            }

            parameters.Add("@UsuarioID", usuarioId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var usuarioList = await _dbConnection.QueryAsync<Usuarios, Roles, Usuarios>(
                    query,
                    (usuario, rol) =>
                    {
                        usuario.Rol = rol; // Asegúrate de que coincida con el nombre de la propiedad en tu clase Usuarios
                        return usuario;
                    },
                    parameters,
                    splitOn: "RolID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = usuarioList.FirstOrDefault() ?? new Usuarios();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Usuarios();
            }

            return resultado;
        }

        public async Task<spInsertUsuariosResults> InsertAsync(Usuarios model)
        {
            var resultado = new spInsertUsuariosResults();
            var query = "spInsertUsuarios";
            var parameters = new DynamicParameters();

            // Validación de negocio: RolID válido, Nombre, Correo y PasswordHash obligatorios
            if (model == null || model.RolID <= 0 || string.IsNullOrWhiteSpace(model.Nombre) || string.IsNullOrWhiteSpace(model.Correo) || string.IsNullOrWhiteSpace(model.PasswordHash))
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: RolID, Nombre, Correo y PasswordHash son obligatorios.";
                return resultado;
            }

            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Correo", model.Correo.Trim());
            parameters.Add("@PasswordHash", model.PasswordHash.Trim());
            parameters.Add("@Telefono", model.Telefono?.Trim() ?? string.Empty);
            parameters.Add("@RolID", model.RolID);

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdateUsuariosResults> UpdateAsync(int idExistente, Usuarios model)
        {
            var resultado = new spUpdateUsuariosResults();
            var query = "spUpdateUsuarios";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || model == null || model.RolID <= 0 || string.IsNullOrWhiteSpace(model.Nombre) || string.IsNullOrWhiteSpace(model.Correo))
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente y RolID deben ser válidos, y los campos Nombre y Correo son obligatorios.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@idExistente", idExistente);
            parameters.Add("@Nombre", model.Nombre.Trim());
            parameters.Add("@Correo", model.Correo.Trim());
            parameters.Add("@Telefono", model.Telefono?.Trim() ?? string.Empty);
            parameters.Add("@RolID", model.RolID);

            // Parámetros OUTPUT del procedimiento de actualización
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.datos = new spUpdateUsuariosResponse
                {
                    IdExistente = idExistente,
                    Nombre = model.Nombre.Trim(),
                    Correo = model.Correo.Trim(),
                    Telefono = model.Telefono?.Trim() ?? string.Empty,
                    RolID = model.RolID,
                    rol = model.Rol
                };
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteUsuariosResults> DeleteAsync(int usuarioId)
        {
            var resultado = new spDeleteUsuariosResults();
            var query = "spDeleteUsuarios";
            var parameters = new DynamicParameters();

            if (usuarioId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteUsuariosResponse
                {
                    IDaEliminar = usuarioId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID de usuario a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetro de entrada exacto que espera tu SP
            parameters.Add("@IDaEliminar", usuarioId);

            // Parámetros OUTPUT que devuelve tu SP
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteUsuariosResponse
                {
                    IDaEliminar = usuarioId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteUsuariosResponse
                {
                    IDaEliminar = usuarioId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}