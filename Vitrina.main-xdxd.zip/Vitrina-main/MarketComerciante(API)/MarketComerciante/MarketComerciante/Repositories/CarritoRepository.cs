﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // 1. INTERFAZ DEL REPOSITORIO
    public interface ICarritoRepository
    {
        Task<spGetAllCarritoResults> GetAllAsync();
        Task<spGetAllIdCarritoResults> GetByIdAsync(int CarritoID);
        Task<spInsertCarritoResults> InsertAsync(Carrito model);
        Task<spUpdateCarritoResults> UpdateAsync(int idExistente, int Cantidad);
        Task<spDeleteCarritoResults> DeleteAsync(int CarritoID);
    }

    // 2. IMPLEMENTACIÓN CON DAPPER
    public class CarritoRepository : ICarritoRepository
    {
        private readonly IDbConnection _dbConnection;

        public CarritoRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }
        // --- MÉTODOS Y VALIDACIONES ---
        public async Task<spGetAllCarritoResults> GetAllAsync()
        {
            var resultado = new spGetAllCarritoResults();
            var query = "spGetAllCarrito";
            var parameters = new DynamicParameters();

            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var carritos = await _dbConnection.QueryAsync<Carrito, Usuarios, Productos, Carrito>(
                    query,
                    (carrito, usuario, producto) =>
                    {
                        carrito.Usuario = usuario;
                        carrito.Producto = producto;
                        return carrito;
                    },
                    parameters,
                    splitOn: "UsuarioID,ProductoID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListasdeCarritos = carritos.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListasdeCarritos = new List<Carrito>();
            }

            return resultado;
        }
        public async Task<spGetAllIdCarritoResults> GetByIdAsync(int CarritoID)
        {
            var resultado = new spGetAllIdCarritoResults();
            var query = "spGetAllIdCarrito";
            var parameters = new DynamicParameters();

            // Validación de entrada: Asegurar que el ID sea mayor a cero 
            if (CarritoID <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El ID proporcionado no es válido.";
                resultado.datos = new Carrito();
                return resultado;
            }

            parameters.Add("@CarritoID", CarritoID);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var carrito = await _dbConnection.QueryAsync<Carrito, Usuarios, Productos, Carrito>(
                    query,
                    (c, u, p) =>
                    {
                        c.Usuario = u;
                        c.Producto = p;
                        return c;
                    },
                    parameters,
                    splitOn: "UsuarioID,ProductoID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = carrito.FirstOrDefault() ?? new Carrito();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Carrito();
            }

            return resultado; }

        public async Task<spInsertCarritoResults> InsertAsync(Carrito model)
        {
            var resultado = new spInsertCarritoResults();
            var query = "spInsertCarrito";
            var parameters = new DynamicParameters();

            // 1. Validación de negocio
            if (model == null || model.UsuarioID <= 0 || model.ProductoID <= 0 || model.Cantidad <= 0)
            {
                resultado.return_value = -1;
                resultado.id_insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: UsuarioID, ProductoID y Cantidad deben ser mayores a cero.";
                resultado.datos = null;
                return resultado;
            }

            // 2. Parámetros de ENTRADA que exige el procedimiento almacenado
            parameters.Add("@UsuarioID", model.UsuarioID);
            parameters.Add("@ProductoID", model.ProductoID);
            parameters.Add("@Cantidad", model.Cantidad);

            // 3. Parámetros de SALIDA (OUTPUT) del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                // Abrir conexión si está cerrada
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                // Ejecución del Stored Procedure
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                // Obtención de los parámetros OUTPUT
                resultado.id_insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Producto agregado al carrito con éxito.";

                resultado.datos = new spInsertCarritoResponse
                {
                    UsuarioID = model.UsuarioID,
                    ProductoID = model.ProductoID,
                    Cantidad = model.Cantidad,
                    FechaAgregado = DateTime.Now
                };

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spUpdateCarritoResults> UpdateAsync(int idExistente, int cantidad)
        {
            var resultado = new spUpdateCarritoResults();
            var query = "spUpdateCarrito";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || cantidad <= 0)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente y la cantidad deben ser valores mayores a cero.";
                resultado.datos = null;
                return resultado;
            }

            // Parámetros de entrada alineados con el SP
            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@Cantidad", cantidad);

            // Parámetro OUTPUT con el nombre exacto del SP (@IdActualizado)
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Cantidad del carrito actualizada.";
                resultado.datos = new spUdateCarritoResponse
                {
                    IdExistente = idExistente,
                    Cantidad = cantidad
                };
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteCarritoResults> DeleteAsync(int carritoId)
        {
            var resultado = new spDeleteCarritoResults();
            var query = "spDeleteCarrito";
            var parameters = new DynamicParameters();

            if (carritoId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCarritoResponse
                {
                    IDaEliminar = carritoId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetros alineados exactamente con el SP
            parameters.Add("@IDaEliminar", carritoId);
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteCarritoResponse
                {
                    IDaEliminar = carritoId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCarritoResponse
                {
                    IDaEliminar = carritoId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}