﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // ==========================================
    // INTERFAZ DEL REPOSITORIO DE GEOLOCALIZACIÓN PEDIDOS
    // ==========================================
    public interface IGeolocalizacionPedidosRepository
    {
        Task<spGetAllGeoPedidosResults> GetAllAsync();
        Task<spGetAllIdGeoPedidosResults> GetByIdAsync(int ubicacionId);
        Task<spInsertGeoPedidosResults> InsertAsync(GeolocalizacionPedidos model);
        Task<spUpdateGeoPedidosResults> UpdateAsync(int idExistente, spUpdateGeoPedidosResponse model);
        Task<spDeleteGeoPedidosResults> DeleteAsync(int ubicacionId);
    }

    // ==========================================
    // IMPLEMENTACIÓN CON DAPPER
    // ==========================================
    public class GeolocalizacionPedidosRepository : IGeolocalizacionPedidosRepository
    {
        private readonly IDbConnection _dbConnection;

        public GeolocalizacionPedidosRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllGeoPedidosResults> GetAllAsync()
        {
            var resultado = new spGetAllGeoPedidosResults();
            var query = "spGetAllGeoPedidos";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var geoPedidos = await _dbConnection.QueryAsync<GeolocalizacionPedidos>(
                    query,
                    parameters, // <- Pasamos los parámetros aquí
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListadeGeoPedidos = geoPedidos.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito"; // <- Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListadeGeoPedidos = new List<GeolocalizacionPedidos>();
            }

            return resultado;
        }

        public async Task<spGetAllIdGeoPedidosResults> GetByIdAsync(int ubicacionId)
        {
            var resultado = new spGetAllIdGeoPedidosResults();
            var query = "spGetAllIdGeoPedidos";
            var parameters = new DynamicParameters();

            // Validación de ID positivo
            if (ubicacionId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El UbicacionID proporcionado no es válido.";
                resultado.datos = new GeolocalizacionPedidos();
                return resultado;
            }

            parameters.Add("@UbicacionID", ubicacionId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var geoPedido = await _dbConnection.QueryAsync<GeolocalizacionPedidos, Pedidos, Comprador, GeolocalizacionPedidos>(
                    query,
                    (geo, pedido, comprador) =>
                    {
                        pedido.comprador = comprador; // Asignamos el comprador al pedido (respetando minúscula/mayúscula de tu modelo)
                        geo.Pedido = pedido;         // Asignamos el pedido a la geolocalización
                        return geo;
                    },
                    parameters,
                    splitOn: "PedidoID,CompradorID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = geoPedido.FirstOrDefault() ?? new GeolocalizacionPedidos();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new GeolocalizacionPedidos();
            }

            return resultado;
        }

        public async Task<spInsertGeoPedidosResults> InsertAsync(GeolocalizacionPedidos model)
        {
            var resultado = new spInsertGeoPedidosResults();
            var query = "spInsertGeoPedidos";
            var parameters = new DynamicParameters();

            if (model == null || model.PedidoID <= 0 || model.LatitudActual < -90 || model.LatitudActual > 90 || model.LongitudActual < -180 || model.LongitudActual > 180)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: PedidoID debe ser mayor a cero y las coordenadas geográficas deben ser válidas.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@PedidoID", model.PedidoID);
            parameters.Add("@LatitudActual", model.LatitudActual);
            parameters.Add("@LongitudActual", model.LongitudActual);

            parameters.Add("@id_Insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_Insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Ubicación registrada con éxito.";

                if (resultado.id_Insertado > 0)
                {
                    // Opcional: Consultamos el registro insertado para devolverlo con su Pedido y Comprador mapeados automáticamente por ID
                    var selectQuery = @"
                SELECT G.[UbicacionID], G.[PedidoID], G.[LatitudActual], G.[LongitudActual], G.[UltimaActualizacion],
                       P.[PedidoID], P.[CompradorID], P.[MontoTotal], P.[Estado], P.[MetodoPago], P.[FechaPedido],
                       C.[CompradorID], C.[Nombre], C.[Correo], C.[PasswordHash], C.[Telefono], C.[FechaRegistro]
                FROM [dbo].[GeolocalizacionPedidos] G
                INNER JOIN [dbo].[Pedidos] P ON G.[PedidoID] = P.[PedidoID]
                INNER JOIN [dbo].[Comprador] C ON P.[CompradorID] = C.[CompradorID]
                WHERE G.[UbicacionID] = @UbicacionID";

                    var geoRegistrada = await _dbConnection.QueryAsync<GeolocalizacionPedidos, Pedidos, Comprador, GeolocalizacionPedidos>(
                        selectQuery,
                        (geo, pedido, comprador) =>
                        {
                            pedido.comprador = comprador;
                            geo.Pedido = pedido;
                            return geo;
                        },
                        new { UbicacionID = resultado.id_Insertado },
                        splitOn: "PedidoID,CompradorID"
                    );

                    resultado.datos = geoRegistrada.FirstOrDefault();
                }

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spUpdateGeoPedidosResults> UpdateAsync(int idExistente, spUpdateGeoPedidosResponse model)
        {
            var resultado = new spUpdateGeoPedidosResults();
            var query = "spUpdateGeoPedidos";
            var parameters = new DynamicParameters();

            if (idExistente <= 0 || model == null || model.PedidoID <= 0 || model.LatitudActual < -90 || model.LatitudActual > 90 || model.LongitudActual < -180 || model.LongitudActual > 180)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "Validación fallida: El ID existente y los datos de geolocalización deben ser válidos.";
                resultado.datos = null;
                return resultado;
            }

            parameters.Add("@idExistente", idExistente);
            parameters.Add("@PedidoID", model.PedidoID);
            parameters.Add("@LatitudActual", model.LatitudActual);
            parameters.Add("@LongitudActual", model.LongitudActual);

            // Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                // Ejecutamos el procedimiento almacenado de actualización
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Actualización procesada.";

                if (resultado.IdActualizado > 0)
                {
                    // Consultamos directamente el registro actualizado mapeándolo a tu modelo plano
                    var selectQuery = @"
                SELECT [UbicacionID] AS [IdExistente], [PedidoID], [LatitudActual], [LongitudActual]
                FROM [dbo].[GeolocalizacionPedidos]
                WHERE [UbicacionID] = @UbicacionID";

                    var geoActualizada = await _dbConnection.QueryFirstOrDefaultAsync<spUpdateGeoPedidosResponse>(
                        selectQuery,
                        new { UbicacionID = resultado.IdActualizado }
                    );

                    resultado.datos = geoActualizada;
                }

                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteGeoPedidosResults> DeleteAsync(int ubicacionId)
        {
            var resultado = new spDeleteGeoPedidosResults();
            var query = "spDeleteGeoPedidos";
            var parameters = new DynamicParameters();

            if (ubicacionId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteGeoPedidosResponse
                {
                    IDaEliminar = ubicacionId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID de ubicación a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetro de entrada que espera el SP
            parameters.Add("@IDaEliminar", ubicacionId);

            // Parámetros OUTPUT que devuelve el SP
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteGeoPedidosResponse
                {
                    IDaEliminar = ubicacionId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteGeoPedidosResponse
                {
                    IDaEliminar = ubicacionId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}