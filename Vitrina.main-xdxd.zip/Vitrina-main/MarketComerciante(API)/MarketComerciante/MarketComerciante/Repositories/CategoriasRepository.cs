﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // INTERFAZ DEL REPOSITORIO DE CATEGORÍAS
    public interface ICategoriasRepository
    {
        Task<spGetAllCategoriasResults> GetAllAsync();
        Task<spGetAllIdCategoriasResults> GetByIdAsync(int categoriaId);
        Task<spInsertCategoriasResults> InsertAsync(spInsertCategoriasResponse model);
        Task<spUpdateCategoriasResults> UpdateAsync(int idExistente, string nombre);
        Task<spDeleteCategoriasResults> DeleteAsync(int categoriaId);
    }

    // IMPLEMENTACIÓN CON DAPPER
    public class CategoriasRepository : ICategoriasRepository
    {
        private readonly IDbConnection _dbConnection;

        public CategoriasRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllCategoriasResults> GetAllAsync()
        {
            var resultado = new spGetAllCategoriasResults();
            var query = "spGetAllCategorias";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var categorias = await _dbConnection.QueryAsync<Categorias>(
                    query,
                    parameters, // <- Pasamos los parámetros aquí
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListadeCategorias = categorias.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito"; // <- Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListadeCategorias = new List<Categorias>();
            }

            return resultado;
        }

        public async Task<spGetAllIdCategoriasResults> GetByIdAsync(int categoriaId)
        {
            var resultado = new spGetAllIdCategoriasResults();
            var query = "spGetAllIdCategorias";
            var parameters = new DynamicParameters();

            // Validación de entrada: El ID debe ser positivo
            if (categoriaId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El CategoriaID proporcionado no es válido.";
                resultado.datos = new Categorias();
                return resultado;
            }

            parameters.Add("@CategoriaID", categoriaId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                var categoria = await _dbConnection.QueryFirstOrDefaultAsync<Categorias>(
                    query,
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = categoria ?? new Categorias();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new Categorias();
            }

            return resultado;
        }

        public async Task<spInsertCategoriasResults> InsertAsync(spInsertCategoriasResponse model)
        {
            var resultado = new spInsertCategoriasResults();
            var query = "spInsertCategorias";
            var parameters = new DynamicParameters();

            // 1. Validación de negocio
            if (model == null || string.IsNullOrWhiteSpace(model.Nombre))
            {
                resultado.return_value = -1;
                resultado.id_insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: El nombre de la categoría es obligatorio.";
                return resultado;
            }

            // 2. Parámetros de entrada que exige el SP en SQL Server
            parameters.Add("@Nombre", model.Nombre.Trim());

            // 3. Parámetros OUTPUT del procedimiento almacenado
            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                // Recogemos los valores devueltos por el SP
                resultado.id_insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Categoría insertada correctamente.";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdateCategoriasResults> UpdateAsync(int idExistente, string nombre)
        {
            var resultado = new spUpdateCategoriasResults();
            var query = "spUpdateCategorias";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || string.IsNullOrWhiteSpace(nombre))
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente debe ser mayor a cero y el nombre no puede estar vacío.";
                resultado.datos = null;
                return resultado;
            }

            // Parámetros de entrada que exige el SP de SQL
            parameters.Add("@IdExistente", idExistente);
            parameters.Add("@Nombre", nombre.Trim());

            // Parámetros de entrada/salida (OUTPUT) que el SP también demanda según su estructura
            parameters.Add("@IdActualizado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                // Recogemos los valores de salida devueltos por el procedimiento almacenado
                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Categoría actualizada con éxito";

                resultado.datos = new spUpdateCategoriasResponse
                {
                    IdExistente = idExistente,
                    Nombre = nombre.Trim()
                };
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteCategoriasResults> DeleteAsync(int categoriaId)
        {
            var resultado = new spDeleteCategoriasResults();
            var query = "spDeleteCategorias";
            var parameters = new DynamicParameters();

            if (categoriaId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCategoriasResponse
                {
                    IDaEliminar = categoriaId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID a eliminar no es válido."
                };
                return resultado;
            }

            // CORRECCIÓN: Usar los nombres exactos que exige el SP en SQL Server
            parameters.Add("@IDaEliminar", categoriaId);
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                // CORRECCIÓN: Leer exactamente los nombres de los parámetros OUTPUT del SP
                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta");

                resultado.return_value = 0;
                resultado.datos = new spDeleteCategoriasResponse
                {
                    IDaEliminar = categoriaId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteCategoriasResponse
                {
                    IDaEliminar = categoriaId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}