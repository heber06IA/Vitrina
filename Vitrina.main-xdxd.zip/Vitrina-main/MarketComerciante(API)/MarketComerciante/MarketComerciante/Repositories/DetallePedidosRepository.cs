﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MarketComerciante.Models;

namespace MarketComerciante.Repositories
{
    // INTERFAZ DEL REPOSITORIO DE DETALLE PEDIDOS
    public interface IDetallePedidosRepository
    {
        Task<spGetAllDetPedidosResults> GetAllAsync();
        Task<spGetAllIdDetPedidosResults> GetByIdAsync(int detalleId);
        Task<spInsertDetPedidosResults> InsertAsync(spInsertDetPedidosResponse model);
        Task<spUpdateDetPedidosResults> UpdateAsync(int idExistente, int cantidad, decimal precioUnitario);
        Task<spDeleteDetPedidoResults> DeleteAsync(int detalleId);
    }
    // IMPLEMENTACIÓN CON DAPPER
    public class DetallePedidosRepository : IDetallePedidosRepository
    {
        private readonly IDbConnection _dbConnection;

        public DetallePedidosRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<spGetAllDetPedidosResults> GetAllAsync()
        {
            var resultado = new spGetAllDetPedidosResults();
            var query = "spGetAllDetPedidos";
            var parameters = new DynamicParameters();

            // Declaramos el parámetro de salida que el procedimiento almacenado espera
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                // Ejecutamos la consulta con Multi-Mapping de Dapper para mapear DetallePedidos, Pedidos y Productos
                var detPedidos = await _dbConnection.QueryAsync<DetallePedidos, Pedidos, Productos, DetallePedidos>(
                    query,
                    (detalle, pedido, producto) =>
                    {
                        detalle.Pedido = pedido;     // Asignamos el objeto Pedido completo
                        detalle.Producto = producto; // Asignamos el objeto Producto completo
                        return detalle;
                    },
                    parameters,
                    splitOn: "PedidoID,ProductoID", // Columnas donde se dividen los objetos anidados
                    commandType: CommandType.StoredProcedure
                );

                resultado.ListadeDetallesPedidos = detPedidos.ToList();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Éxito"; // Capturamos el mensaje del SP
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetAllAsync: {ex.Message}";
                resultado.ListadeDetallesPedidos = new List<DetallePedidos>();
            }

            return resultado;
        }

        public async Task<spGetAllIdDetPedidosResults> GetByIdAsync(int detalleId)
        {
            var resultado = new spGetAllIdDetPedidosResults();
            var query = "spGetAllIdDetPedidos"; // Ajusta si tu SP se llama diferente
            var parameters = new DynamicParameters();

            if (detalleId <= 0)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = "El DetalleID proporcionado no es válido.";
                resultado.datos = new DetallePedidos();
                return resultado;
            }

            parameters.Add("@DetalleID", detalleId);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                var detalleList = await _dbConnection.QueryAsync<DetallePedidos, Pedidos, Productos, DetallePedidos>(
                    query,
                    (detalle, pedido, producto) =>
                    {
                        detalle.Pedido = pedido;     // Hidrata el objeto Pedido
                        detalle.Producto = producto; // Hidrata el objeto Producto
                        return detalle;
                    },
                    parameters,
                    splitOn: "PedidoID,ProductoID",
                    commandType: CommandType.StoredProcedure
                );

                resultado.datos = detalleList.FirstOrDefault() ?? new DetallePedidos();
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Exito";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.mensaje_respuesta = $"Error en GetByIdAsync: {ex.Message}";
                resultado.datos = new DetallePedidos();
            }

            return resultado;
        }

        public async Task<spInsertDetPedidosResults> InsertAsync(spInsertDetPedidosResponse model)
        {
            var resultado = new spInsertDetPedidosResults();
            var query = "spInsertDetallePedidos";
            var parameters = new DynamicParameters();

            if (model == null || model.PedidoID <= 0 || model.ProductoID <= 0 || model.Cantidad <= 0 || model.PrecioUnitario < 0)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = "Validación fallida: PedidoID, ProductoID, Cantidad deben ser mayores a cero y PrecioUnitario válido.";
                return resultado;
            }

            parameters.Add("@PedidoID", model.PedidoID);
            parameters.Add("@ProductoID", model.ProductoID);
            parameters.Add("@Cantidad", model.Cantidad);
            parameters.Add("@PrecioUnitario", model.PrecioUnitario);

            parameters.Add("@id_insertado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                if (_dbConnection.State != ConnectionState.Open && _dbConnection.State != ConnectionState.Connecting)
                {
                    _dbConnection.Open();
                }

                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.id_Insertado = parameters.Get<int>("@id_insertado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta") ?? "Detalle de pedido insertado exitosamente.";
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.id_Insertado = 0;
                resultado.mensaje_respuesta = $"Error en InsertAsync: {ex.Message}";
            }

            return resultado;
        }

        public async Task<spUpdateDetPedidosResults> UpdateAsync(int idExistente, int cantidad, decimal precioUnitario)
        {
            var resultado = new spUpdateDetPedidosResults();
            var query = "spUpdateDetPedidos";
            var parameters = new DynamicParameters();

            // Validación de parámetros para actualización
            if (idExistente <= 0 || cantidad <= 0 || precioUnitario < 0)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = "El ID existente y la cantidad deben ser mayores a cero, y el precio unitario no puede ser negativo.";
                resultado.datos = null;
                return resultado;
            }

            // Parámetros de entrada
            parameters.Add("@IdActualizado", idExistente);
            parameters.Add("@Cantidad", cantidad);
            parameters.Add("@PrecioUnitario", precioUnitario);

            // Parámetros OUTPUT configurados correctamente con su dirección
            parameters.Add("@IdExistente", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);
            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                resultado.IdActualizado = parameters.Get<int>("@IdActualizado");
                resultado.mensaje_respuesta = parameters.Get<string>("@mensaje_respuesta");
                resultado.datos = new spUpdateDetPedidosResponse
                {
                    IdExistente = idExistente,
                    Cantidad = cantidad,
                    PrecioUnitario = precioUnitario
                };
                resultado.return_value = 0;
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.IdActualizado = 0;
                resultado.mensaje_respuesta = $"Error en UpdateAsync: {ex.Message}";
                resultado.datos = null;
            }

            return resultado;
        }

        public async Task<spDeleteDetPedidoResults> DeleteAsync(int detalleId)
        {
            var resultado = new spDeleteDetPedidoResults();
            var query = "spDeleteDetPedidos";
            var parameters = new DynamicParameters();

            if (detalleId <= 0)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteDetPedidosResponse
                {
                    IDaEliminar = detalleId,
                    IDeliminado = 0,
                    mensaje_respuesta = "El ID a eliminar no es válido."
                };
                return resultado;
            }

            // Parámetros corregidos para que coincidan exactamente con el SP
            parameters.Add("@IDAEliminar", detalleId);
            parameters.Add("@IDeliminado", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@mensaje_respuesta", dbType: DbType.String, direction: ParameterDirection.Output, size: -1);

            try
            {
                await _dbConnection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                int idEliminado = parameters.Get<int>("@IDeliminado");
                string mensaje = parameters.Get<string>("@mensaje_respuesta") ?? "Proceso completado.";

                resultado.return_value = 0;
                resultado.datos = new spDeleteDetPedidosResponse
                {
                    IDaEliminar = detalleId,
                    IDeliminado = idEliminado,
                    mensaje_respuesta = mensaje
                };
            }
            catch (Exception ex)
            {
                resultado.return_value = -1;
                resultado.datos = new spDeleteDetPedidosResponse
                {
                    IDaEliminar = detalleId,
                    IDeliminado = 0,
                    mensaje_respuesta = $"Error en DeleteAsync: {ex.Message}"
                };
            }

            return resultado;
        }
    }
}