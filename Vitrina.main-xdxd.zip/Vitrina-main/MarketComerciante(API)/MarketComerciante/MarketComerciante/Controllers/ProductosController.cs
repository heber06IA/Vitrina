﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly IProductosRepository _productosRepository;

        public ProductosController(IProductosRepository productosRepository)
        {
            _productosRepository = productosRepository;
        }

        /// <summary>
        /// Obtiene todos los productos registrados.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllProductos()
        {
            var resultado = await _productosRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un producto específico por su ProductoID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductoById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del producto debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _productosRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.ProductoID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún producto con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo producto.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarProducto([FromBody] spInsertProductosResponse model)
        {
            if (model == null || model.TiendaID <= 0 || model.CategoriaID <= 0 || string.IsNullOrWhiteSpace(model.Nombre))
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío y se requieren TiendaID, CategoriaID y Nombre válidos." });
            }

            var resultado = await _productosRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la información de un producto existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarProducto(int id, [FromBody] spUpdateProductosResponse model)
        {
            if (id <= 0 || model == null)
            {
                return BadRequest(new { mensaje = "El ID del producto debe ser mayor a cero y los datos de actualización son obligatorios." });
            }

            var resultado = await _productosRepository.UpdateAsync(id, model);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El producto que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un producto por su ProductoID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarProducto(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _productosRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el producto a eliminar." });
            }

            return Ok(resultado);
        }
    }
}