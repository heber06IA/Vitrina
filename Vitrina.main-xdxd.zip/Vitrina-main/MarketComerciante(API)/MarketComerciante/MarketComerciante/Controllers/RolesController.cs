﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly IRolesRepository _rolesRepository;

        public RolesController(IRolesRepository rolesRepository)
        {
            _rolesRepository = rolesRepository;
        }

        /// <summary>
        /// Obtiene todos los roles registrados en el sistema.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllRoles()
        {
            var resultado = await _rolesRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un rol específico por su RolID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRolById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del rol debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _rolesRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.RolID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún rol con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo rol.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarRol([FromBody] Roles model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.Nombre))
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío y el nombre del rol es obligatorio." });
            }

            var resultado = await _rolesRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza un rol existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarRol(int id, [FromQuery] string nombreRol)
        {
            if (id <= 0 || string.IsNullOrWhiteSpace(nombreRol))
            {
                return BadRequest(new { mensaje = "El ID del rol debe ser mayor a cero y se requiere un nuevo nombre válido." });
            }

            var resultado = await _rolesRepository.UpdateAsync(id, nombreRol);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El rol que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un rol por su RolID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarRol(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _rolesRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el rol a eliminar." });
            }

            return Ok(resultado);
        }
    }
}