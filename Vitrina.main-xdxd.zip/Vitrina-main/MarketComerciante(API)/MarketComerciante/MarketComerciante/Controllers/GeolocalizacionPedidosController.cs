﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeolocalizacionPedidosController : ControllerBase
    {
        private readonly IGeolocalizacionPedidosRepository _geoPedidosRepository;

        public GeolocalizacionPedidosController(IGeolocalizacionPedidosRepository geoPedidosRepository)
        {
            _geoPedidosRepository = geoPedidosRepository;
        }

        /// <summary>
        /// Obtiene todos los registros de geolocalización de pedidos.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllGeoPedidos()
        {
            var resultado = await _geoPedidosRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un registro de geolocalización específico por su UbicacionID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetGeoPedidoById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID de ubicación debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _geoPedidosRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.UbicacionID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún registro de geolocalización con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo registro de geolocalización para un pedido.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarGeolocalizacion([FromBody] spInsertGeoPedidosResponse response)
        {
            if (   response  == null)
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío." });
            }

            if (response.PedidoID <= 0 || response.LatitudActual < -90 || response.LatitudActual > 90 || response.LongitudActual < -180 || response.LongitudActual > 180)
            {
                return BadRequest(new { mensaje = "El PedidoID debe ser mayor a cero y las coordenadas geográficas deben ser válidas." });
            }

            // Mapeamos los datos limpios de la petición al modelo que espera tu repositorio
            var model = new GeolocalizacionPedidos
            {
                PedidoID = response.PedidoID,
                LatitudActual = response.LatitudActual,
                LongitudActual = response.LongitudActual
            };

            var resultado = await _geoPedidosRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(resultado);
            }

            return Ok(resultado);
        }
        /// <summary>
        /// Actualiza la geolocalización de un pedido existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarGeoPedido(int id, [FromBody] spUpdateGeoPedidosResponse model)
        {
            if (id <= 0 || model == null)
            {
                return BadRequest(new { mensaje = "El ID de ubicación debe ser mayor a cero y los datos de actualización son obligatorios." });
            }

            var resultado = await _geoPedidosRepository.UpdateAsync(id, model);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El registro de geolocalización que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un registro de geolocalización por su UbicacionID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarGeoPedido(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _geoPedidosRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el registro de geolocalización a eliminar." });
            }

            return Ok(resultado);
        }
    }
}