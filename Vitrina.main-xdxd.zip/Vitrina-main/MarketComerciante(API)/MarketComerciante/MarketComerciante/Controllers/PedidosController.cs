﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidosController : ControllerBase
    {
        private readonly IPedidosRepository _pedidosRepository;

        public PedidosController(IPedidosRepository pedidosRepository)
        {
            _pedidosRepository = pedidosRepository;
        }

        /// <summary>
        /// Obtiene todos los pedidos registrados en el sistema.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllPedidos()
        {
            var resultado = await _pedidosRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un pedido específico por su PedidoID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetPedidoById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del pedido debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _pedidosRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.PedidoID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún pedido con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo pedido.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarPedido([FromBody] spInsertPedidosResponse model)
        {
            if (model == null || model.CompradorID <= 0 || model.MontoTotal <= 0)
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío y se requiere un CompradorID y MontoTotal válidos." });
            }

            var resultado = await _pedidosRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la información de un pedido existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarPedido(int id, [FromBody] spUpdatePedidosResponse model)
        {
            if (id <= 0 || model == null)
            {
                return BadRequest(new { mensaje = "El ID del pedido debe ser mayor a cero y los datos de actualización son obligatorios." });
            }

            var resultado = await _pedidosRepository.UpdateAsync(id, model);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El pedido que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un pedido por su PedidoID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarPedido(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _pedidosRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el pedido a eliminar." });
            }

            return Ok(resultado);
        }
    }
}