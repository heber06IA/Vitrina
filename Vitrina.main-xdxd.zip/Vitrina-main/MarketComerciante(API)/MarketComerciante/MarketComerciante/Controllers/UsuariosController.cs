﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly IUsuariosRepository _usuariosRepository;

        public UsuariosController(IUsuariosRepository usuariosRepository)
        {
            _usuariosRepository = usuariosRepository;
        }

        /// <summary>
        /// Obtiene todos los usuarios registrados.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllUsuarios()
        {
            var resultado = await _usuariosRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un usuario específico por su UsuarioID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetUsuarioById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del usuario debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _usuariosRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.UsuarioID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún usuario con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo usuario.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarUsuario([FromBody] Usuarios model)
        {
            if (model == null || model.RolID <= 0 || string.IsNullOrWhiteSpace(model.Nombre) || string.IsNullOrWhiteSpace(model.Correo))
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío y se requieren RolID, Nombre y Correo válidos." });
            }

            var resultado = await _usuariosRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la información de un usuario existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarUsuario(int id, [FromBody] Usuarios model)
        {
            if (id <= 0 || model == null)
            {
                return BadRequest(new { mensaje = "El ID del usuario debe ser mayor a cero y los datos de actualización son obligatorios." });
            }

            var resultado = await _usuariosRepository.UpdateAsync(id, model);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El usuario que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un usuario por su UsuarioID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarUsuario(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _usuariosRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el usuario a eliminar." });
            }

            return Ok(resultado);
        }
    }
}