﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TiendasController : ControllerBase
    {
        private readonly ITiendasRepository _tiendasRepository;

        public TiendasController(ITiendasRepository tiendasRepository)
        {
            _tiendasRepository = tiendasRepository;
        }

        /// <summary>
        /// Obtiene todas las tiendas registradas.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllTiendas()
        {
            var resultado = await _tiendasRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene una tienda específica por su TiendaID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetTiendaById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID de la tienda debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _tiendasRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.TiendaID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ninguna tienda con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta una nueva tienda.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarTienda([FromBody] spInsertTiendasResponse model)
        {
            if (model == null || model.UsuarioID <= 0 || string.IsNullOrWhiteSpace(model.NombreTienda))
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío y se requieren UsuarioID y NombreTienda válidos." });
            }

            var resultado = await _tiendasRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la información de una tienda existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarTienda(int id, [FromBody] spUdateTiendasResponse model)
        {
            if (id <= 0 || model == null)
            {
                return BadRequest(new { mensaje = "El ID de la tienda debe ser mayor a cero y los datos de actualización son obligatorios." });
            }

            var resultado = await _tiendasRepository.UpdateAsync(id, model);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "La tienda que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina una tienda por su TiendaID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarTienda(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _tiendasRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar la tienda a eliminar." });
            }

            return Ok(resultado);
        }
    }
}