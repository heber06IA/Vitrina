﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompradorController : ControllerBase
    {
        private readonly ICompradorRepository _compradorRepository;

        public CompradorController(ICompradorRepository compradorRepository)
        {
            _compradorRepository = compradorRepository;
        }

        /// <summary>
        /// Obtiene todos los compradores registrados.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllCompradores()
        {
            var resultado = await _compradorRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un comprador específico por su IDComprador.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCompradorById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del comprador debe ser un número entero positivo mayor a cero." });
            }

            var resultado = await _compradorRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.CompradorID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún comprador con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo comprador.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarComprador([FromBody] spInsertCompradorResponse model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.Correo))
            {
                return BadRequest(new { mensaje = "El correo y los datos del comprador son obligatorios." });
            }

            var resultado = await _compradorRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la información de un comprador existente.
        /// </summary>
        [HttpPut("{id}")]
public async Task<IActionResult> ActualizarComprador(int idExistente, [FromBody] spUdateCompradorResponse model)
{
    if (idExistente <= 0 || model == null)
    {
        return BadRequest(new { mensaje = "El ID debe ser mayor a cero y los datos de actualización son obligatorios." });
    }

    var resultado = await _compradorRepository.UpdateAsync(idExistente, model);

    if (resultado.return_value < 0 || resultado.IdActualizado == 0)
    {
        return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El comprador que intenta actualizar no existe." });
    }

    return Ok(resultado);
}

        /// <summary>
        /// Elimina un comprador por su IDComprador.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarComprador(int compradorId)
        {
            if (compradorId <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _compradorRepository.DeleteAsync(compradorId);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el comprador a eliminar." });
            }

            return Ok(resultado);
        }
    }
}