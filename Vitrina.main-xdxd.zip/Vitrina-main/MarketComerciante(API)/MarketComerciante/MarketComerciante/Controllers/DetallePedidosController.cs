﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetallePedidosController : ControllerBase
    {
        private readonly IDetallePedidosRepository _detallePedidosRepository;

        public DetallePedidosController(IDetallePedidosRepository detallePedidosRepository)
        {
            _detallePedidosRepository = detallePedidosRepository;
        }

        /// <summary>
        /// Obtiene todos los detalles de pedidos registrados.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> ObtenerDetallesPedidos()
        {
            var resultado = await _detallePedidosRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un detalle de pedido específico por su DetalleID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerDetallePedidoPorId(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID debe ser mayor a cero." });
            }

            var resultado = await _detallePedidosRepository.GetByIdAsync(id);

            if (resultado.return_value < 0 || resultado.datos.DetalleID == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo detalle de pedido.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarDetallePedido([FromBody] spInsertDetPedidosResponse model)
        {
            if (model == null || model.PedidoID <= 0 || model.ProductoID <= 0 || model.Cantidad <= 0)
            {
                return BadRequest(new { mensaje = "Los campos PedidoID, ProductoID y Cantidad son obligatorios y deben ser mayores a cero." });
            }

            var resultado = await _detallePedidosRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_Insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la cantidad y precio unitario de un detalle de pedido existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarDetallePedido(int id, [FromQuery] int cantidad, [FromQuery] decimal precioUnitario)
        {
            if (id <= 0 || cantidad <= 0 || precioUnitario < 0)
            {
                return BadRequest(new { mensaje = "El ID y la cantidad deben ser mayores a cero, y el precio unitario no puede ser negativo." });
            }

            var resultado = await _detallePedidosRepository.UpdateAsync(id, cantidad, precioUnitario);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El detalle de pedido que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un detalle de pedido por su DetalleID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarDetallePedido(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _detallePedidosRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el detalle de pedido a eliminar." });
            }

            return Ok(resultado);
        }
    }
}