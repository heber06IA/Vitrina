﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarritoController : ControllerBase
    {
        private readonly ICarritoRepository _carritoRepository;

        public CarritoController(ICarritoRepository carritoRepository)
        {
            _carritoRepository = carritoRepository;
        }

        /// <summary>
        /// Obtiene todos los registros del carrito de compras.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllCarritos()
        {
            var resultado = await _carritoRepository.GetAllAsync();

            // Validación y Verificación: Si el resultado indica un error interno o viene vacío
            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene un registro específico del carrito según su CarritoID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCarritoById(int id)
        {
            // Validación de entrada: El ID debe ser mayor a 0
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID del carrito debe ser un valor entero positivo mayor a cero." });
            }

            var resultado = await _carritoRepository.GetByIdAsync(id);

            // Verificación: Comprobamos si se encontró el registro o si hubo error
            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.CarritoID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ningún registro en el carrito con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta un nuevo producto en el carrito de compras.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> InsertarCarrito([FromBody] spInsertCarritoResponse model)
        {
            if (model == null)
            {
                return BadRequest(new { mensaje = "El cuerpo de la solicitud no puede estar vacío." });
            }

            if (model.UsuarioID <= 0 || model.ProductoID <= 0 || model.Cantidad <= 0)
            {
                return BadRequest(new { mensaje = "Los campos UsuarioID, ProductoID y Cantidad son obligatorios y deben ser mayores a cero." });
            }

            // Mapeamos al modelo Carrito que espera tu repositorio
            var carritoModel = new Carrito
            {
                UsuarioID = model.UsuarioID,
                ProductoID = model.ProductoID,
                Cantidad = model.Cantidad
            };

            var resultado = await _carritoRepository.InsertAsync(carritoModel);

            if (resultado.return_value < 0 || resultado.id_insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza la cantidad de un producto existente en el carrito.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarCarrito(int id, [FromQuery] int cantidad)
        {
            // Validación de parámetros de entrada
            if (id <= 0 || cantidad <= 0)
            {
                return BadRequest(new { mensaje = "El ID del carrito y la nueva cantidad deben ser mayores a cero." });
            }

            var resultado = await _carritoRepository.UpdateAsync(id, cantidad);

            // Verificación si el registro existía o hubo problemas en la actualización
            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El registro que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina un registro del carrito por su ID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarCarrito(int id)
        {
            // Validación de entrada
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _carritoRepository.DeleteAsync(id);

            // Verificación del estado de eliminación
            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar el registro a eliminar." });
            }

            return Ok(resultado);
        }
    }
}