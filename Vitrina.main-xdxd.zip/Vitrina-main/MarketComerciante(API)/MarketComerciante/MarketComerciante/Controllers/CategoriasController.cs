﻿using Microsoft.AspNetCore.Mvc;
using MarketComerciante.Models;
using MarketComerciante.Repositories;
using System.Threading.Tasks;

namespace MarketComerciante.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriasController : ControllerBase
    {
        private readonly ICategoriasRepository _categoriasRepository;

        public CategoriasController(ICategoriasRepository categoriasRepository)
        {
            _categoriasRepository = categoriasRepository;
        }

        /// <summary>
        /// Obtiene la lista completa de categorías.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetAllCategorias()
        {
            var resultado = await _categoriasRepository.GetAllAsync();

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Obtiene una categoría específica por su CategoriaID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategoriaById(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID de la categoría debe ser un valor entero positivo mayor a cero." });
            }

            var resultado = await _categoriasRepository.GetByIdAsync(id);

            if (resultado.return_value < 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            if (resultado.datos == null || resultado.datos.CategoriaID == 0)
            {
                return NotFound(new { mensaje = $"No se encontró ninguna categoría con el ID {id}." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Inserta una nueva categoría.
        /// </summary>
        [HttpPost]
        [HttpPost]
        public async Task<IActionResult> InsertarCategoria([FromBody] spInsertCategoriasResponse model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.Nombre))
            {
                return BadRequest(new { mensaje = "El campo 'nombre' es obligatorio." });
            }

            var resultado = await _categoriasRepository.InsertAsync(model);

            if (resultado.return_value < 0 || resultado.id_insertado == 0)
            {
                return BadRequest(new { mensaje = resultado.mensaje_respuesta });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Actualiza una categoría existente.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarCategoria(int id, [FromQuery] string nombre)
        {
            if (id <= 0 || string.IsNullOrWhiteSpace(nombre))
            {
                return BadRequest(new { mensaje = "El ID de la categoría debe ser mayor a cero y se requiere un nuevo nombre válido." });
            }

            var resultado = await _categoriasRepository.UpdateAsync(id, nombre);

            if (resultado.return_value < 0 || resultado.IdActualizado == 0)
            {
                return NotFound(new { mensaje = resultado.mensaje_respuesta ?? "El registro que intenta actualizar no existe." });
            }

            return Ok(resultado);
        }

        /// <summary>
        /// Elimina una categoría por su CategoriaID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarCategoria(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new { mensaje = "El ID a eliminar debe ser un número entero positivo." });
            }

            var resultado = await _categoriasRepository.DeleteAsync(id);

            if (resultado.return_value < 0 || resultado.datos.IDeliminado == 0)
            {
                return NotFound(new { mensaje = resultado.datos.mensaje_respuesta ?? "No se pudo encontrar la categoría a eliminar." });
            }

            return Ok(resultado);
        }
    }
}