using System.Data;
using Microsoft.Data.SqlClient;
using MarketComerciante.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// 1. Obtener la cadena de conexión desde appsettings.json usando el nombre correcto ("ConexionsQL")
var connectionString = builder.Configuration.GetConnectionString("ConexionsQL");

// 2. Registrar la conexión como un servicio Scoped utilizando SqlConnection
builder.Services.AddScoped<IDbConnection>((provider) => new SqlConnection(connectionString));

// 3. Registrar tu repositorio
builder.Services.AddScoped<ICarritoRepository, CarritoRepository>();
builder.Services.AddScoped<ICompradorRepository, CompradorRepository>();
builder.Services.AddScoped<ICategoriasRepository, CategoriasRepository>();
builder.Services.AddScoped<IDetallePedidosRepository, DetallePedidosRepository>();
builder.Services.AddScoped<IGeolocalizacionPedidosRepository, GeolocalizacionPedidosRepository>();
builder.Services.AddScoped<IPedidosRepository, PedidosRepository>();
builder.Services.AddScoped<IProductosRepository, ProductosRepository>();
builder.Services.AddScoped<IRolesRepository, RolesRepository>();
builder.Services.AddScoped<ITiendasRepository, TiendasRepository>();
builder.Services.AddScoped<IUsuariosRepository, UsuariosRepository>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();